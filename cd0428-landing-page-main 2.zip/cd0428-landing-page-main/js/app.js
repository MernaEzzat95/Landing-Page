// Global Scope Variables
const menuBar = document.getElementById("navbar__list");
const sections = document.querySelectorAll("section");
const docFragment = document.createDocumentFragment() // New Document Fragment

//building Nav Bar
function createNavBar() {
    sections.forEach(section =>{
     const secId = section.getAttribute("id") // Getting The Id
     const secTitle = section.getAttribute("data-nav") // Getting The Title
     const navBarItem = document.createElement("li")
     const navBarLink = document.createElement("a")

     navBarLink.classList.add("menu__link");
     navBarLink.href =`#${secId}`
     navBarLink.textContent = secTitle
     navBarLink.addEventListener("click", evt => {
      evt.preventDefault()

      // Setting The Smooth Behavior On Scrolling
      section.scrollIntoView({
        behavior: "smooth"
    })
})
//appendChild To The menuBar Variable
navBarItem.appendChild(navBarLink)
docFragment.appendChild(navBarItem)
    })
    menuBar.appendChild(docFragment)
    }

    // Calling The Function
createNavBar();

// Setting The Activity Of Each Section
window.onscroll = function() {
    document.querySelectorAll("section").forEach(function (active) {
        if (
            active.getBoundingClientRect().top >= -200 &&
            active.getBoundingClientRect().top <= 200
        ) {
            active.classList.add("your-active-class");
        } else {
            active.classList.remove("your-active-class");
        }
    });
};