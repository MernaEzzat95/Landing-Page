# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

Hello;

This is my Landing Page Project!

Here's the steps of my Project:

1. First, I created the Navigation Bar and I've set its properties
- by creating variables in the global scope,
- then creating the function called (createNavBar) which contain loop to excute the orders on each section
- the I've linked the "menu__link" class to the navBar link and creating their names by their titles
- then I added the eventListner "click" to each one of them
- lastly, I've set the smooth behavior of scrolling to the page by scrollIntoView method
- appending all this childs to the menuBar variable
- calling on the function.

2. Secondly, I've set the activity of section by using getBoundingClientRect inside if condition

Hope you inform me for any improvments
Thank You ...